#include <graphics.h>
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <iostream.h>
typedef unsigned int outcode;
int TOP=1,BOTTOM=2,RIGHT=4,LEFT=8;
void drawline(int x1,int y1,int x2,int y2)
{
	int xmax = getmaxx(), ymax = getmaxy();
	line(xmax / 2, 0, xmax / 2, ymax);
	line(0, ymax / 2, xmax, ymax / 2);
    line(x1+xmax,ymax-y1,xmax+x2,ymax-y2);
}
outcode CompOutCode(double x,double y,
double xmin,double xmax,double ymin,double ymax)
{
    outcode code=0;
    if(y>ymax)
      code|=TOP;
    else if(y<ymin)
      code|=BOTTOM;
    if(x>xmax)
       code|=RIGHT;
    else if(x<xmin)
       code|=LEFT;
    return code;
}
void cohenSutherLandLineClipAndDraw(
    double x0,double y0,double xl,double yl,double xmin,double xmax,double ymin,double ymax)
{
    outcode outcode0,outcode1,outcodeOut;
    boolean accept=FALSE,done=FALSE;
    outcode0=CompOutCode(x0,y0,xmin,xmax,ymin,ymax);
    outcode1=CompOutCode(x1,y1,xmin,xmax,ymin,ymax);
    do{
        if(!(outcode0 | outcode1)){
            accept=TRUE;
            done=TRUE;
        }else if(outcode0 &outcode1){
            done=TRUE;
        }
        else{
            double x,y;
            outcodeOut=outcode0 ? outcode0:outcode1;
            if(outcodeOut & TOP){
                x=x0+(xl-x0)*(ymax-y0)/(yl-y0);
                y=ymax;
            }else if(outcodeOut & BOTTOM){
                x=x0+(xl-x0)*(ymin-y0)/(yl-y0);
                y=ymin;
            }else if(outcodeOut & RIGHT){
                y=y0+(yl-y0)*(xmax-x0)/(xl-x0);
                x=xmax;
            }else{
                y=y0+(yl-y0)*(xmin-x0)/(xl-x0);
                x=xmin;
            }
        }
    }while(done==FALSE);
    if(accept){
        
       drawline(x0,y0,xl,yl);
    }
}
int main(void)
{
   /* request auto detection */
   int gdriver = DETECT, gmode, errorcode;
   int xmax, ymax;

   /* initialize graphics and local variables */
   initgraph(&gdriver, &gmode, "C:\\TURBOC3\\BGI");

   /* read result of initialization */
   errorcode = graphresult();
   /* an error occurred */
   if (errorcode != grOk)
   {
      printf("Graphics error: %s\n", grapherrormsg(errorcode));
      printf("Press any key to halt:");
      getch();
      exit(1);
   }
//    drawline(0,0,100,100);
//    drawline(20,20,80,20);
//    drawline(20,20,20,80);
//    drawline(20,80,80,80);
//    drawline(80,20,80,80);
//    cleardevice();
//    getch();
   cohenSutherLandLineClipAndDraw(0,0,100,100,20,80,20,80);
//    drawline(20,20,80,20);
//    drawline(20,20,20,80);
//    drawline(20,80,80,80);
//    drawline(80,20,80,80);
   
   /* clean up */
   getch();
   closegraph();
   return 0;
}
