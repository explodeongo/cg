#include <iostream.h>
#include <graphics.h>
#include <conio.h>
#include <math.h>

void drawObject(int x[], int y[], int n) {
    for (int i = 0; i < n - 1; i++) {
        line(x[i], y[i], x[i + 1], y[i + 1]);
    }
    line(x[n - 1], y[n - 1], x[0], y[0]);
}

void translate(int x[], int y[], int n, int tx, int ty) {
    for (int i = 0; i < n; i++) {
        x[i] += tx;
        y[i] += ty;
    }
}

void rotate(int x[], int y[], int n, float angle) {
    float rad = angle * 3.14159265 / 180;
    int ox = x[0], oy = y[0]; // Origin point

    for (int i = 0; i < n; i++) {
        int xp = x[i] - ox;
        int yp = y[i] - oy;
        x[i] = ox + xp * cos(rad) - yp * sin(rad);
        y[i] = oy + xp * sin(rad) + yp * cos(rad);
    }
}

void scale(int x[], int y[], int n, float sx, float sy) {
    int ox = x[0], oy = y[0]; // Origin point

    for (int i = 0; i < n; i++) {
	int xp = x[i] - ox;
	int yp = y[i] - oy;
	x[i] = ox + xp * sx;
	y[i] = oy + yp * sy;
    }
}

void shear(int x[], int y[], int n, float shx, float shy) {
    for (int i = 0; i < n; i++) {
	x[i] += shx * x[i];
	y[i] += shy * y[i];
    }
}

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "C:\\TURBOC3\\BGI");

    // Get window size
    int maxx = getmaxx();
    int maxy = getmaxy();

    // Draw x-axis and y-axis
    line(0, maxy / 2, maxx, maxy / 2); // x-axis
    line(maxx / 2, 0, maxx / 2, maxy); // y-axis

    int n;
    cout << "Enter the number of vertices of the polygon: ";
    cin >> n;

    int *x = new int[n];
    int *y = new int[n];

    cout << "Enter the coordinates of the polygon vertices (x y format):\n";
    for (int i = 0; i < n; i++) {
	cin >> x[i] >> y[i];
    }

    // Translate polygon to the origin of the window
    translate(x, y, n, maxx / 2, maxy / 2);
    rotate(x,y,n,-90);
    drawObject(x, y, n); // Original Object

    int choice;
    cout << "Choose a transformation:\n";
    cout << "1. Translate\n";
    cout << "2. Rotate\n";
    cout << "3. Scale\n";
    cout << "4. Shear\n";
    cout << "Enter your choice: ";
    cin >> choice;

    switch (choice) {
	case 1: {
	    int tx, ty;
	    cout << "Enter translation factors (tx ty): ";
	    cin >> tx >> ty;
	    translate(x, y, n, tx, ty);
	    break;
	}
	case 2: {
	    float angle;
	    cout << "Enter rotation angle (in degrees): ";
	    cin >> angle;
	    rotate(x, y, n, angle);
	    break;
	}
	case 3: {
	    float sx, sy;
	    cout << "Enter scaling factors (sx sy): ";
	    cin >> sx >> sy;
	    scale(x, y, n, sx, sy);
	    break;
	}
	case 4: {
	    float shx, shy;
	    cout << "Enter shearing factors (shx shy): ";
	    cin >> shx >> shy;
	    shear(x, y, n, shx, shy);
	    break;
	}
	default:
	    cout << "Invalid choice";
    }

    setcolor(RED);
    drawObject(x, y, n); // Transformed Object

    delete[] x;
    delete[] y;

    getch();
    closegraph();
    return 0;
}