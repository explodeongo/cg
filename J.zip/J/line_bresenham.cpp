#include <iostream>
#include <graphics.h>

void draw_line(int x0, int y0, int x1, int y1) {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "C:\\TURBOC3\\BGI");

    putpixel(x0, y0, WHITE);

    int dx = abs(x1 - x0);
    int dy = abs(y1 - y0);
    int p0 = 2 * dy - dx;

    int x = x0, y = y0;

    while (x != x1 || y != y1) {
        if (p0 <= 0) {
            x++;
            putpixel(x, y, WHITE);
            p0 += 2 * dy;
        } else {
            x++;
            y++;
            putpixel(x, y, WHITE);
            p0 += 2 * dy - 2 * dx;
        }
    }

    getch();
    closegraph();
}

int main() {
    int x0 = 50, y0 = 50; // Starting point
    int x1 = 200, y1 = 150; // Ending point

    draw_line(x0, y0, x1, y1);

    return 0;
}
