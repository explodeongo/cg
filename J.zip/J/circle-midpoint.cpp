#include <iostream>
#include <graphics.h>
#include <conio.h>

void setPixel(int x, int y, int xCenter, int yCenter) {
    putpixel(xCenter + x, yCenter - y, WHITE); // Subtract y from yCenter for y-axis inversion
    putpixel(xCenter - x, yCenter - y, WHITE);
    putpixel(xCenter + x, yCenter + y, WHITE); // Add y to yCenter for y-axis inversion
    putpixel(xCenter - x, yCenter + y, WHITE);
    putpixel(xCenter + y, yCenter - x, WHITE); // Swap x and y for y-axis inversion
    putpixel(xCenter - y, yCenter - x, WHITE);
    putpixel(xCenter + y, yCenter + x, WHITE); // Swap x and y for y-axis inversion
    putpixel(xCenter - y, yCenter + x, WHITE);
}

void circleMidpoint(int xCenter, int yCenter, int radius) {
    int x = 0;
    int y = radius;
    int p = 1 - radius;

    setPixel(x, y, xCenter, yCenter);

    while (x < y) {
        x++;
        if (p < 0)
            p += 2 * x + 1;
        else {
            y--;
            p += 2 * (x - y) + 1;
        }
        setPixel(x, y, xCenter, yCenter);
    }
}

void drawAxes(int centerX, int centerY) {

    line(0, centerY, getmaxx(), centerY);
    line(centerX, 0, centerX, getmaxy());
}

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "C:\\TURBOC3\\BGI");

    int centerX = getmaxx() / 2;
    int centerY = getmaxy() / 2;

    int radius = 100;

    drawAxes(centerX, centerY);

    // Draw the circle in the specified quadrant
    circleMidpoint(centerX + 200, centerY - 0, radius);
    //circleMidpoint(centerX - 200, centerY + 0, radius);

    getch();
    closegraph();
    return 0;
}
