#include <iostream>
#include <graphics.h>
#include <conio.h>
#include <math.h>

#define ROUND(a) ((int)(a+0.5))

void lineDDA(int xa, int ya, int xb, int yb) {
    int dx = xb - xa, dy = yb - ya, steps, k;
    float xIncrement, yIncrement, x = xa, y = ya;

    if (abs(dx) > abs(dy))
        steps = abs(dx);
    else
        steps = abs(dy);

    xIncrement = dx / (float)steps;
    yIncrement = dy / (float)steps;

    putpixel(ROUND(x), ROUND(y), WHITE);

    for (k = 0; k < steps; k++) {
        x += xIncrement;
        y += yIncrement;
        putpixel(ROUND(x), ROUND(y), WHITE);
    }
}

void drawMappedLine(int xa, int ya, int xb, int yb) {
    // Get the center of the screen
    int centerX = getmaxx() / 2;
    int centerY = getmaxy() / 2;

    // Draw the line from (xa, ya) to (xb, yb) with respect to the center of the screen
    lineDDA(xa + centerX, centerY - ya, xb + centerX, centerY - yb);

    // Map the line to other quadrants
    lineDDA(-xa + centerX, centerY - ya, -xb + centerX, centerY - yb); // Second quadrant
    lineDDA(-xa + centerX, centerY + ya, -xb + centerX, centerY + yb); // Third quadrant
    lineDDA(xa + centerX, centerY + ya, xb + centerX, centerY + yb);   // Fourth quadrant
}

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "C:\\TURBOC3\\BGI");

    // Define the coordinates of the line
    int xa = 0;
    int ya = 0;
    int xb = 100;
    int yb = 200;

    // Draw the mapped line
    drawMappedLine(xa, ya, xb, yb);

    // Draw x-axis
    line(0, getmaxy() / 2, getmaxx(), getmaxy() / 2);

    // Draw y-axis
    line(getmaxx() / 2, 0, getmaxx() / 2, getmaxy());

    getch();
    closegraph();
    return 0;
}
