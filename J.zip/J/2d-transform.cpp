#include <iostream>
#include <graphics.h>
#include <conio.h>
#include <cmath>

const int WIDTH = 800;
const int HEIGHT = 600;

// Function to draw the original shape (rectangle in this case)
void drawOriginalShape(int x, int y) {
    setcolor(RED);
    rectangle(x, y, x + 100, y + 50);
}

// Function to draw the updated shape with different color
void drawUpdatedShape(int x, int y, int color) {
    setcolor(color);
    rectangle(x, y, x + 100, y + 50);
}

// Function to translate the shape
void translate(int& x, int& y, int dx, int dy) {
    x += dx;
    y += dy;
}

// Function to rotate the shape
void rotate(int& x, int& y, int angle) {
    double radian = angle * 3.14159 / 180.0;
    int new_x = x * cos(radian) - y * sin(radian);
    int new_y = x * sin(radian) + y * cos(radian);
    x = new_x;
    y = new_y;
}

// Function to scale the shape
void scale(int& x, int& y, float sx, float sy) {
    x *= sx;
    y *= sy;
}

// Function to reflect the shape
void reflect(int& x, int& y) {
    x = -x;
}

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");

    int x = WIDTH / 2 - 50;
    int y = HEIGHT / 2 - 25;
    int originalColor = GREEN;
    int updatedColor = BLUE;

    drawOriginalShape(x, y);

    while (!kbhit()) {
        char choice;
        std::cout << "Enter operation: ";
        std::cin >> choice;

        switch (choice) {
            case 't': {
                int dx, dy;
                std::cout << "Enter translation along x-axis: ";
                std::cin >> dx;
                std::cout << "Enter translation along y-axis: ";
                std::cin >> dy;
                translate(x, y, dx, dy);
                break;
            }
            case 'r': {
                int angle;
                std::cout << "Enter rotation angle in degrees: ";
                std::cin >> angle;
                rotate(x, y, angle);
                break;
            }
            case 's': {
                float sx, sy;
                std::cout << "Enter scaling factor along x-axis: ";
                std::cin >> sx;
                std::cout << "Enter scaling factor along y-axis: ";
                std::cin >> sy;
                scale(x, y, sx, sy);
                break;
            }
            case 'f': {
                reflect(x, y);
                break;
            }
            default:
                std::cout << "Invalid choice!";
        }

        cleardevice(); // Clear the screen
        drawOriginalShape(WIDTH / 2 - 50, HEIGHT / 2 - 25); // Redraw original shape
        drawUpdatedShape(x, y, updatedColor); // Draw updated shape
        delay(1000); // Delay to hold the updated shape
    }

    closegraph();
    return 0;
}
