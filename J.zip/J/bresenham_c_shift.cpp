#include <iostream>
#include <graphics.h>
#include <conio.h>

void draw_line(int x0, int y0, int x1, int y1) {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "C:\\TURBOC3\\BGI");

    putpixel(x0, y0, WHITE);

    int dx = abs(x1 - x0);
    int dy = abs(y1 - y0);
    int sx = (x0 < x1) ? 1 : -1;
    int sy = (y0 < y1) ? 1 : -1;
    int err = dx - dy;
    int x = x0, y = y0;

    while (x != x1 || y != y1) {
        putpixel(x, y, WHITE);
        int e2 = 2 * err;
        if (e2 > -dy) {
            err -= dy;
            x += sx;
        }
        if (e2 < dx) {
            err += dx;
            y += sy;
        }
    }

    getch();
    closegraph();
}

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "C:\\TURBOC3\\BGI");

    // Get the center of the screen
    int centerX = getmaxx() / 2;
    int centerY = getmaxy() / 2;

    // Draw X-axis
    line(0, centerY, getmaxx(), centerY);

    // Draw Y-axis
    line(centerX, 0, centerX, getmaxy());

    // Define the coordinates of the line wrt the center of the screen
    int xa = 0, ya = 0;     // Starting point
    int xb = 100, yb = 100; // Ending point

    // Map the line to the center
    int x0 = centerX + xa;
    int y0 = centerY - ya;
    int x1 = centerX + xb;
    int y1 = centerY - yb;

    // Draw the mapped line using the provided function
    draw_line(x0, y0, x1, y1);

    // Close the graphics window
    closegraph();

    return 0;
}
